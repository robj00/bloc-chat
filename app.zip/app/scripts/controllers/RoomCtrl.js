(function() {
     function RoomCtrl() {
        this.roomData = {
            rooms: ['one' , 'two']
        };
         console.log (this.roomData);
     }
 
     angular
         .module('blocChat')
         .controller('RoomCtrl', RoomCtrl );
})();